╔══════════════════════════════════════════╗
║         KALPRO VPN — SOURCE FILES        ║
║           Version 1.0 Build 1            ║
╚══════════════════════════════════════════╝

HOW TO USE THESE FILES IN ANDROIDIDE / CODEASSIST
═══════════════════════════════════════════════════

STEP 1 — Copy each file to its exact location in your project.

FOLDER STRUCTURE:
app/src/main/
├── AndroidManifest.xml
├── java/com/kalpro/vpn/
│   ├── MainActivity.java
│   ├── KalproVpnService.java
│   ├── TunnelManager.java
│   └── BootReceiver.java
└── res/
    ├── layout/
    │   └── activity_main.xml
    ├── values/
    │   ├── themes.xml
    │   ├── colors.xml
    │   └── strings.xml
    ├── values-night/
    │   └── values.xml
    ├── xml/
    │   └── file_paths.xml
    ├── drawable/
    │   ├── ic_launcher_background.xml
    │   └── ic_launcher_foreground.xml
    ├── mipmap/
    │   ├── ic_launcher.xml
    │   └── ic_launcher_round.xml
    └── mipmap-anydpi-v26/
        ├── ic_launcher.xml
        └── ic_launcher_round.xml

STEP 2 — In module.toml / Build Features:
  - View Binding = OFF

STEP 3 — Dependencies needed:
  - androidx.appcompat:appcompat:1.6.1
  - androidx.core:core:1.9.0

STEP 4 — Clean Project → Build → Run

PROTOCOLS SUPPORTED:
  • SSH (Direct / SNI / Payload)
  • V2Ray (VMess/VLESS)
  • Trojan (TLS)
  • DNSTT (DNS Tunnel)

FEATURES:
  • Protocol selector dialog
  • Connect / Disconnect button
  • Export config as kal:// link
  • Import from kal:// link
  • Live log console
  • Dark purple theme
  • Auto-scroll logs
