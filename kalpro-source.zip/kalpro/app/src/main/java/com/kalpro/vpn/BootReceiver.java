package com.kalpro.vpn;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            Log.d("KALPRO_BOOT", "Boot received — ready for auto-reconnect.");
            // Auto reconnect will be added in next version
        }
    }
}
