package com.kalpro.vpn;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import org.json.JSONObject;

public class KalproVpnService extends VpnService {

    private static final String TAG = "KALPRO_SERVICE";
    private static final String CHANNEL_ID = "kalpro_vpn";
    private static final int NOTIF_ID = 1001;

    public static boolean isRunning = false;
    private TunnelManager tunnelManager;

    @Override
    public void onCreate() {
        super.onCreate();
        tunnelManager = new TunnelManager(this);
        createNotificationChannel();
        Log.d(TAG, "Service created.");
    }

    @Override
    public int onStartCommand(
            Intent intent, int flags, int startId) {
        isRunning = true;

        try {
            startForeground(NOTIF_ID, buildNotification());
        } catch (Throwable t) {
            Log.e(TAG, "Foreground error: " + t.getMessage());
        }

        if (intent != null) {
            String configData =
                intent.getStringExtra("CONFIG_DATA");
            if (configData != null) {
                try {
                    JSONObject json = new JSONObject(configData);
                    String protocol = json.optString("protocol", "SSH");
                    String server   = json.optString("server", "");
                    String payload  = json.optString("payload", "");
                    int    port     = json.optInt("port", 22);
                    String sni      = json.optString("sni", "");
                    String password = json.optString("password", "");

                    tunnelManager.startTunnel(
                        protocol, server, payload, port, sni, password);

                } catch (Exception e) {
                    Log.e(TAG, "Config parse error: " + e.getMessage());
                }
            }
        }

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        isRunning = false;
        if (tunnelManager != null) {
            tunnelManager.stopTunnel();
        }
        try {
            stopForeground(true);
        } catch (Throwable t) {
            Log.e(TAG, t.getMessage());
        }
        Log.d(TAG, "Service destroyed.");
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID, "KALPRO VPN",
                NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("KALPRO tunnel active");
            NotificationManager nm =
                getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    private Notification buildNotification() {
        Intent ni = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(
            this, 0, ni, PendingIntent.FLAG_IMMUTABLE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            return new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("KALPRO VPN")
                .setContentText("Tunnel is active")
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
        } else {
            return new Notification.Builder(this)
                .setContentTitle("KALPRO VPN")
                .setContentText("Tunnel is active")
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
        }
    }
}
