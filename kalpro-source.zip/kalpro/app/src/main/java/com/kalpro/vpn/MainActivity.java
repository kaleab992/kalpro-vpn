package com.kalpro.vpn;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    TextView tvProtocolSelector;
    TextView tvProtocolInfo;
    TextView tvConfigDisplay;
    EditText edtServer;
    EditText edtPort;
    TextView txtLogs;
    ScrollView scrollLogs;
    Button btnConnect;
    Button btnExport;
    TextView btnMenu;

    String selectedProtocol = "SSH";
    boolean isConnected = false;

    String[] PROTOCOLS = {
        "SSH", "V2RAY", "TROJAN", "DNSTT"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            setContentView(R.layout.activity_main);
        } catch (Throwable t) {
            Toast.makeText(this,
                "Layout error: " + t.getMessage(),
                Toast.LENGTH_LONG).show();
            return;
        }

        try {
            tvProtocolSelector =
                (TextView) findViewById(R.id.tv_protocol_selector);
            tvProtocolInfo =
                (TextView) findViewById(R.id.tv_protocol_info);
            tvConfigDisplay =
                (TextView) findViewById(R.id.tv_config_display);
            edtServer =
                (EditText) findViewById(R.id.edt_server);
            edtPort =
                (EditText) findViewById(R.id.edt_port);
            txtLogs =
                (TextView) findViewById(R.id.txt_logs);
            scrollLogs =
                (ScrollView) findViewById(R.id.scroll_logs);
            btnConnect =
                (Button) findViewById(R.id.btn_connect);
            btnExport =
                (Button) findViewById(R.id.btn_export);
            btnMenu =
                (TextView) findViewById(R.id.btn_menu);

        } catch (Throwable t) {
            Toast.makeText(this,
                "View error: " + t.getMessage(),
                Toast.LENGTH_LONG).show();
            return;
        }

        try {
            applyProtocol("SSH");

            // Protocol selector
            tvProtocolSelector.setOnClickListener(v -> {
                new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Select Protocol")
                    .setItems(PROTOCOLS, (d, w) -> {
                        applyProtocol(PROTOCOLS[w]);
                    })
                    .show();
            });

            // Connect button
            btnConnect.setOnClickListener(v -> handleConnect());

            // Export button
            btnExport.setOnClickListener(v -> handleExport());

            // Menu button
            btnMenu.setOnClickListener(v -> showMenu());

            log("[KALPRO] Engine Ready ✓");
            log("[SYSTEM] Version 1.0 — Build 1");

        } catch (Throwable t) {
            Toast.makeText(this,
                "Init error: " + t.getMessage(),
                Toast.LENGTH_LONG).show();
        }
    }

    void handleConnect() {
        try {
            String host = edtServer.getText().toString().trim();
            String portStr = edtPort.getText().toString().trim();

            if (host.isEmpty()) {
                Toast.makeText(this,
                    "Enter server host", Toast.LENGTH_SHORT).show();
                return;
            }
            if (portStr.isEmpty()) {
                Toast.makeText(this,
                    "Enter port", Toast.LENGTH_SHORT).show();
                return;
            }

            int port = Integer.parseInt(portStr);

            if (!isConnected) {
                // Start VPN service
                Intent vpnIntent = new Intent(this, KalproVpnService.class);
                vpnIntent.putExtra("CONFIG_DATA",
                    buildConfigJson(selectedProtocol, host, port));
                startService(vpnIntent);

                isConnected = true;
                btnConnect.setText("DISCONNECT");
                log("[" + selectedProtocol + "] Connecting → "
                    + host + ":" + port);
                log("[STATUS] Tunnel starting...");
            } else {
                // Stop VPN service
                stopService(new Intent(this, KalproVpnService.class));
                isConnected = false;
                btnConnect.setText("CONNECT");
                log("[STATUS] Tunnel stopped.");
            }
        } catch (Throwable t) {
            log("[ERROR] " + t.getMessage());
        }
    }

    void handleExport() {
        try {
            String host = edtServer.getText().toString().trim();
            String port = edtPort.getText().toString().trim();
            if (host.isEmpty()) {
                Toast.makeText(this,
                    "Enter server first",
                    Toast.LENGTH_SHORT).show();
                return;
            }

            String config = buildConfigJson(
                selectedProtocol, host,
                port.isEmpty() ? 0 : Integer.parseInt(port));

            // Show export options
            String[] options = {
                "Share as kal:// link",
                "Copy to clipboard"
            };

            new AlertDialog.Builder(this)
                .setTitle("Export Config")
                .setItems(options, (d, w) -> {
                    if (w == 0) {
                        // Share as link
                        String link = "kal://import?data="
                            + android.util.Base64.encodeToString(
                                config.getBytes(),
                                android.util.Base64.URL_SAFE
                                | android.util.Base64.NO_WRAP);
                        Intent share = new Intent(Intent.ACTION_SEND);
                        share.setType("text/plain");
                        share.putExtra(Intent.EXTRA_TEXT, link);
                        startActivity(Intent.createChooser(
                            share, "Share KALPRO Config"));
                        log("[EXPORT] Shared as kal:// link");
                    } else {
                        // Copy to clipboard
                        android.content.ClipboardManager cm =
                            (android.content.ClipboardManager)
                            getSystemService(CLIPBOARD_SERVICE);
                        android.content.ClipData clip =
                            android.content.ClipData.newPlainText(
                                "KALPRO Config", config);
                        cm.setPrimaryClip(clip);
                        Toast.makeText(this,
                            "Config copied!", Toast.LENGTH_SHORT).show();
                        log("[EXPORT] Config copied to clipboard");
                    }
                })
                .show();

        } catch (Throwable t) {
            log("[ERROR] Export: " + t.getMessage());
        }
    }

    void showMenu() {
        String[] items = {
            "Import from link",
            "About KALPRO"
        };
        new AlertDialog.Builder(this)
            .setTitle("KALPRO Menu")
            .setItems(items, (d, w) -> {
                if (w == 0) {
                    // Import from link dialog
                    EditText input = new EditText(this);
                    input.setHint("Paste kal:// link here");
                    input.setTextColor(0xFFFFFFFF);
                    input.setHintTextColor(0xFF555555);
                    new AlertDialog.Builder(this)
                        .setTitle("Import Config")
                        .setView(input)
                        .setPositiveButton("Import", (dd, ww) -> {
                            String link = input.getText().toString().trim();
                            handleImportLink(link);
                        })
                        .setNegativeButton("Cancel", null)
                        .show();
                } else {
                    new AlertDialog.Builder(this)
                        .setTitle("KALPRO v1.0")
                        .setMessage(
                            "KALPRO Secure Tunnel\n"
                            + "Version 1.0 Build 1\n\n"
                            + "Protocols:\n"
                            + "• SSH Direct\n"
                            + "• V2Ray/VMess\n"
                            + "• Trojan TLS\n"
                            + "• DNSTT\n\n"
                            + "Config format: .kal")
                        .setPositiveButton("OK", null)
                        .show();
                }
            })
            .show();
    }

    void handleImportLink(String link) {
        try {
            if (!link.startsWith("kal://")) {
                Toast.makeText(this,
                    "Invalid kal:// link",
                    Toast.LENGTH_SHORT).show();
                return;
            }
            String data = link.substring(
                link.indexOf("data=") + 5);
            String json = new String(
                android.util.Base64.decode(data,
                    android.util.Base64.URL_SAFE));
            org.json.JSONObject obj =
                new org.json.JSONObject(json);
            String proto = obj.optString("protocol", "SSH");
            String server = obj.optString("server", "");
            int port = obj.optInt("port", 22);

            edtServer.setText(server);
            edtPort.setText(String.valueOf(port));
            applyProtocol(proto);

            Toast.makeText(this,
                "Config imported!", Toast.LENGTH_SHORT).show();
            log("[IMPORT] Loaded " + proto + " config");
        } catch (Throwable t) {
            Toast.makeText(this,
                "Import failed: " + t.getMessage(),
                Toast.LENGTH_SHORT).show();
        }
    }

    String buildConfigJson(
            String protocol, String server, int port) {
        return "{"
            + "\"protocol\":\"" + protocol + "\","
            + "\"server\":\"" + server + "\","
            + "\"port\":" + port + ","
            + "\"sni\":\"" + server + "\","
            + "\"payload\":\"\","
            + "\"password\":\"\""
            + "}";
    }

    void applyProtocol(String p) {
        selectedProtocol = p;

        if (tvProtocolSelector != null)
            tvProtocolSelector.setText(p + "  ▼");

        switch (p) {
            case "SSH":
                if (tvProtocolInfo != null)
                    tvProtocolInfo.setText(
                        "SSH  •  Direct → Target");
                if (edtPort != null)
                    edtPort.setText("22");
                if (tvConfigDisplay != null)
                    tvConfigDisplay.setText(
                        "username : password");
                break;
            case "V2RAY":
                if (tvProtocolInfo != null)
                    tvProtocolInfo.setText(
                        "V2RAY  •  VMess  •  TLS");
                if (edtPort != null)
                    edtPort.setText("443");
                if (tvConfigDisplay != null)
                    tvConfigDisplay.setText(
                        "UUID: [set in config]\n"
                        + "Network: ws\n"
                        + "TLS: true\n"
                        + "Path: /");
                break;
            case "TROJAN":
                if (tvProtocolInfo != null)
                    tvProtocolInfo.setText(
                        "TROJAN  •  TLS Tunnel");
                if (edtPort != null)
                    edtPort.setText("443");
                if (tvConfigDisplay != null)
                    tvConfigDisplay.setText(
                        "Password: [set in config]\n"
                        + "SNI: your.server.com\n"
                        + "TLS: true");
                break;
            case "DNSTT":
                if (tvProtocolInfo != null)
                    tvProtocolInfo.setText(
                        "DNSTT  •  DNS Tunnel");
                if (edtPort != null)
                    edtPort.setText("53");
                if (tvConfigDisplay != null)
                    tvConfigDisplay.setText(
                        "DNS: tunnel.example.com\n"
                        + "Pubkey: [base32 key]");
                break;
        }

        log("[SWITCH] Protocol → " + p);
    }

    void log(String msg) {
        if (txtLogs == null) return;
        String c = txtLogs.getText().toString();
        txtLogs.setText(c.isEmpty()
            ? msg : c + "\n" + msg);
        // Auto scroll to bottom
        if (scrollLogs != null) {
            scrollLogs.post(() ->
                scrollLogs.fullScroll(ScrollView.FOCUS_DOWN));
        }
    }
}
