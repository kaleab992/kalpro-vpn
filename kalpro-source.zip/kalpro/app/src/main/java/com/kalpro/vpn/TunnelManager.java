package com.kalpro.vpn;

import android.content.Context;
import android.util.Log;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

public class TunnelManager {

    private static final String TAG = "KALPRO_TUNNEL";
    private Context context;
    private Process nativeProcess;
    private boolean isTunnelRunning = false;

    public TunnelManager(Context context) {
        this.context = context;
    }

    public void startTunnel(
            String protocol,
            String server,
            String payload,
            int port,
            String sni,
            String password) {

        if (isTunnelRunning) stopTunnel();
        isTunnelRunning = true;

        Log.d(TAG, "Starting: " + protocol
            + " → " + server + ":" + port);

        switch (protocol.toUpperCase()) {
            case "SSH":
                if (sni != null && !sni.isEmpty()
                        && !sni.equals(server)) {
                    runSSHSni(server, port, sni);
                } else if (payload != null
                        && !payload.isEmpty()) {
                    runSSHPayload(server, port, payload);
                } else {
                    runSSHDirect(server, port);
                }
                break;
            case "V2RAY":
                runV2Ray(server, port, sni, password);
                break;
            case "TROJAN":
                runTrojan(server, port, sni, password);
                break;
            case "DNSTT":
                runDNSTT(server, payload);
                break;
            default:
                Log.e(TAG, "Unknown: " + protocol);
                isTunnelRunning = false;
        }
    }

    // SSH Direct
    private void runSSHDirect(String host, int port) {
        new Thread(() -> {
            try (Socket s = new Socket()) {
                s.connect(new InetSocketAddress(host, port), 10000);
                Log.d(TAG, "SSH Direct connected");
                keepAlive(s);
            } catch (Exception e) {
                Log.e(TAG, "SSH Direct: " + e.getMessage());
                isTunnelRunning = false;
            }
        }).start();
    }

    // SSH + Payload
    private void runSSHPayload(
            String host, int port, String payload) {
        new Thread(() -> {
            try (Socket s = new Socket()) {
                s.connect(new InetSocketAddress(host, port), 10000);
                OutputStream out = s.getOutputStream();
                out.write(payload.getBytes(StandardCharsets.UTF_8));
                out.flush();
                Log.d(TAG, "SSH Payload sent");
                keepAlive(s);
            } catch (Exception e) {
                Log.e(TAG, "SSH Payload: " + e.getMessage());
                isTunnelRunning = false;
            }
        }).start();
    }

    // SSH SNI (TLS)
    private void runSSHSni(
            String host, int port, String sni) {
        new Thread(() -> {
            try {
                SSLSocketFactory f =
                    (SSLSocketFactory) SSLSocketFactory.getDefault();
                SSLSocket s = (SSLSocket) f.createSocket(host, port);
                s.startHandshake();
                Log.d(TAG, "SSH SNI connected");
                keepAlive(s);
            } catch (Exception e) {
                Log.e(TAG, "SSH SNI: " + e.getMessage());
                isTunnelRunning = false;
            }
        }).start();
    }

    // V2Ray
    private void runV2Ray(
            String server, int port,
            String sni, String uuid) {
        try {
            String cfg = buildV2RayConfig(server, port, sni, uuid);
            String cfgPath = context.getFilesDir() + "/v2ray_config.json";
            FileWriter fw = new FileWriter(cfgPath);
            fw.write(cfg);
            fw.close();
            String bin = context.getFilesDir() + "/v2ray";
            nativeProcess = Runtime.getRuntime()
                .exec(new String[]{bin, "-config", cfgPath});
            Log.d(TAG, "V2Ray started");
        } catch (Exception e) {
            Log.e(TAG, "V2Ray: " + e.getMessage());
            isTunnelRunning = false;
        }
    }

    // Trojan
    private void runTrojan(
            String server, int port,
            String sni, String password) {
        try {
            String cfg = buildTrojanConfig(server, port, sni, password);
            String cfgPath = context.getFilesDir() + "/trojan_config.json";
            FileWriter fw = new FileWriter(cfgPath);
            fw.write(cfg);
            fw.close();
            String bin = context.getFilesDir() + "/trojan";
            nativeProcess = Runtime.getRuntime()
                .exec(new String[]{bin, "-config", cfgPath});
            Log.d(TAG, "Trojan started");
        } catch (Exception e) {
            Log.e(TAG, "Trojan: " + e.getMessage());
            isTunnelRunning = false;
        }
    }

    // DNSTT
    private void runDNSTT(String dnsServer, String pubkey) {
        try {
            String bin = context.getFilesDir() + "/dnstt_client";
            nativeProcess = Runtime.getRuntime()
                .exec(new String[]{
                    bin,
                    "-udp", dnsServer + ":53",
                    "-pubkey", pubkey,
                    "127.0.0.1:8080"});
            Log.d(TAG, "DNSTT started");
        } catch (Exception e) {
            Log.e(TAG, "DNSTT: " + e.getMessage());
            isTunnelRunning = false;
        }
    }

    // Keep alive loop
    private void keepAlive(Socket socket) throws Exception {
        InputStream in = socket.getInputStream();
        byte[] buf = new byte[4096];
        while (isTunnelRunning && !socket.isClosed()) {
            int n = in.read(buf);
            if (n == -1) break;
        }
    }

    // Config builders
    private String buildV2RayConfig(
            String server, int port,
            String sni, String uuid) {
        return "{\"inbounds\":[{\"port\":10808,"
            + "\"protocol\":\"socks\","
            + "\"settings\":{\"auth\":\"noauth\"}}],"
            + "\"outbounds\":[{\"protocol\":\"vmess\","
            + "\"settings\":{\"vnext\":[{"
            + "\"address\":\"" + server + "\","
            + "\"port\":" + port + ","
            + "\"users\":[{\"id\":\"" + uuid + "\","
            + "\"alterId\":0}]}]},"
            + "\"streamSettings\":{\"network\":\"ws\","
            + "\"security\":\"tls\","
            + "\"tlsSettings\":{\"serverName\":\""
            + sni + "\"}}}]}";
    }

    private String buildTrojanConfig(
            String server, int port,
            String sni, String password) {
        return "{\"run_type\":\"client\","
            + "\"local_addr\":\"127.0.0.1\","
            + "\"local_port\":1080,"
            + "\"remote_addr\":\"" + server + "\","
            + "\"remote_port\":" + port + ","
            + "\"password\":[\"" + password + "\"],"
            + "\"ssl\":{\"sni\":\"" + sni + "\","
            + "\"verify\":true}}";
    }

    public void stopTunnel() {
        isTunnelRunning = false;
        if (nativeProcess != null) {
            nativeProcess.destroy();
            nativeProcess = null;
        }
        Log.d(TAG, "Tunnel stopped.");
    }

    public boolean isConnected() {
        return isTunnelRunning;
    }
}
